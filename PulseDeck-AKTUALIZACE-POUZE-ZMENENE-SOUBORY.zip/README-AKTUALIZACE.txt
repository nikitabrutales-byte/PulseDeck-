PULSEDECK – POUZE AKTUALIZACE BETA

Tento balíček NENÍ kompletní aplikace. Obsahuje pouze dva upravené zdrojové soubory:
- app/src/main/assets/index.html
- app/src/main/java/com/pulsedeck/dj/MainActivity.kt

Změny:
- Beat Jump -1/+1 beat pro každou desku na obrazovce DESKY
- průhledné PLAY/PAUSE tlačítko pro každou desku na obrazovce MIXER
- skrytí horní stavové a spodní navigační lišty Androidu při spuštění a návratu do aplikace

Jak aktualizaci vložit do větve pulsedeck-update-beta:
1. Otevři repozitář nikitabrutales-byte/PulseDeckAndroid a přepni na pulsedeck-update-beta.
2. Otevři app/src/main/assets/index.html a nahraď jeho obsah souborem ze stejné cesty v ZIPu.
3. Otevři app/src/main/java/com/pulsedeck/dj/MainActivity.kt a nahraď jeho obsah souborem ze stejné cesty v ZIPu.
4. Commit změn do pulsedeck-update-beta. Nevybírej main.
5. Spusť Actions workflow Build PulseDeck Android pro tuto větev, pokud se nespustí automaticky.

Poznámka: ZIP sám o sobě není APK. APK vznikne až úspěšným sestavením v GitHub Actions.

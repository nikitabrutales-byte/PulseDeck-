package cz.domunfc.beta

import android.app.Activity
import android.content.Context
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.Ndef
import android.nfc.tech.NfcA
import android.nfc.tech.NfcB
import android.nfc.tech.NfcF
import android.nfc.tech.NfcV
import android.nfc.tech.IsoDep
import android.nfc.tech.MifareClassic
import android.nfc.tech.MifareUltralight
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity(), NfcAdapter.ReaderCallback {
    private var adapter: NfcAdapter? = null
    private lateinit var result: TextView
    private lateinit var status: TextView
    private lateinit var scanButton: Button
    private lateinit var stopButton: Button
    private var scanning = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        adapter = NfcAdapter.getDefaultAdapter(this)
        buildUi()
        updateNfcStatus()
    }

    private fun buildUi() {
        val bg = 0xFF101720.toInt()
        val panel = 0xFF192532.toInt()
        val white = 0xFFEDF3F7.toInt()
        val muted = 0xFFB1C0CC.toInt()
        val blue = 0xFF236C91.toInt()

        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(12))
        }
        val title = TextView(this).apply {
            text = "⌁  Domu NFC"
            textSize = 27f
            setTextColor(white)
            gravity = Gravity.START
        }
        val subtitle = TextView(this).apply {
            text = "BETA 0.1  ·  Diagnostika mobilního přístupu"
            textSize = 14f
            setTextColor(muted)
            setPadding(0, dp(6), 0, dp(20))
        }
        status = TextView(this).apply {
            textSize = 15f
            setTextColor(white)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(panel)
        }
        val intro = TextView(this).apply {
            text = "Přilož čip ke čtečce NFC telefonu až po spuštění skenování. Aplikace zobrazuje dostupné technické informace; nekopíruje klíče ani neodemyká dveře."
            textSize = 15f
            setTextColor(muted)
            setPadding(0, dp(16), 0, dp(16))
        }
        scanButton = Button(this).apply {
            text = "Spustit NFC diagnostiku"
            setBackgroundColor(blue)
            setTextColor(white)
            setOnClickListener { startScan() }
        }
        stopButton = Button(this).apply {
            text = "Zastavit skenování"
            setOnClickListener { stopScan() }
        }
        result = TextView(this).apply {
            text = "Zatím nebyl načten žádný čip."
            textSize = 14f
            setTextColor(0xFFBDE4F8.toInt())
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(0xFF0C131A.toInt())
        }
        val help = TextView(this).apply {
            text = "\nJak pokračovat\n1. Ověř, že je NFC zapnuté v nastavení telefonu.\n2. Stiskni „Spustit NFC diagnostiku“.\n3. Přilož přívěsek nebo kartu k zadní straně telefonu.\n4. Pošli výsledek technologií správci domu nebo sem pro další určení kompatibility.\n\nPoznámka: neúspěšné načtení neznamená vadný čip. Může jít o 125kHz RFID nebo zabezpečený systém."
            textSize = 14f
            setTextColor(muted)
            setPadding(0, dp(18), 0, dp(8))
        }
        content.addView(title)
        content.addView(subtitle)
        content.addView(status)
        content.addView(intro)
        content.addView(scanButton)
        content.addView(stopButton)
        content.addView(TextView(this).apply { text = "\nVýsledek"; textSize = 18f; setTextColor(white) })
        content.addView(result)
        content.addView(help)
        scroll.addView(content)
        outer.addView(scroll)
        setContentView(outer)
    }

    private fun updateNfcStatus() {
        status.text = when {
            adapter == null -> "Tento telefon nemá dostupný NFC adaptér."
            adapter?.isEnabled == false -> "NFC je vypnuté. Zapni ho v nastavení telefonu."
            else -> "NFC je dostupné. Spusť diagnostiku a přilož čip."
        }
        scanButton.isEnabled = adapter != null && adapter?.isEnabled == true
    }

    private fun startScan() {
        val nfc = adapter
        if (nfc == null) {
            status.text = "Telefon nemá NFC adaptér."
            return
        }
        if (!nfc.isEnabled) {
            status.text = "NFC je vypnuté. Zapni jej v nastavení telefonu."
            return
        }
        try {
            nfc.enableReaderMode(
                this,
                this,
                NfcAdapter.FLAG_READER_NFC_A or
                    NfcAdapter.FLAG_READER_NFC_B or
                    NfcAdapter.FLAG_READER_NFC_F or
                    NfcAdapter.FLAG_READER_NFC_V or
                    NfcAdapter.FLAG_READER_NO_PLATFORM_SOUNDS,
                null
            )
            scanning = true
            status.text = "Skenování běží. Přilož čip nebo kartu k zadní straně telefonu."
        } catch (e: Exception) {
            status.text = "Skenování nelze spustit: ${e.message ?: "neznámá chyba"}"
        }
    }

    private fun stopScan() {
        adapter?.disableReaderMode(this)
        scanning = false
        status.text = "Skenování zastaveno."
    }

    override fun onTagDiscovered(tag: Tag) {
        val techs = tag.techList.map { it.substringAfterLast('.') }.distinct().sorted()
        val ndef = try {
            val n = Ndef.get(tag)
            if (n != null) {
                n.connect()
                val type = n.type ?: "neuveden"
                val writable = if (n.isWritable) "ano" else "ne"
                val max = n.maxSize
                n.close()
                "NDEF: ano\nTyp NDEF: $type\nZapisovatelný: $writable\nKapacita: $max bajtů"
            } else "NDEF: nebyl rozpoznán"
        } catch (_: Exception) {
            "NDEF: nepodařilo se ověřit"
        }
        val likely = buildList {
            if ("NfcA" in techs) add("NFC-A (13,56 MHz; může zahrnovat různé typy karet)")
            if ("NfcB" in techs) add("NFC-B")
            if ("NfcF" in techs) add("NFC-F")
            if ("NfcV" in techs) add("NFC-V / ISO 15693")
            if ("IsoDep" in techs) add("ISO-DEP / ISO 14443-4")
            if ("MifareClassic" in techs) add("MIFARE Classic (podpora závisí na telefonu)")
            if ("MifareUltralight" in techs) add("MIFARE Ultralight")
        }
        val report = "Čip rozpoznán\n\nDostupné technologie:\n" +
            (if (techs.isEmpty()) "Neuvedeny" else techs.joinToString("\n")) +
            "\n\nMožné vodítko:\n" + (if (likely.isEmpty()) "Z dostupných údajů nelze určit." else likely.joinToString("\n")) +
            "\n\n$ndef\n\nDůležité: technologie sama o sobě nepotvrzuje, že jde o přístupový čip, ani zda jej lze emulovat. Aplikace neukládá ani nevypisuje identifikátor čipu."
        runOnUiThread {
            result.text = report
            status.text = "Čip detekován. Skenování zůstává aktivní; přilož další čip nebo skenování zastav."
        }
    }

    override fun onResume() {
        super.onResume()
        updateNfcStatus()
    }

    override fun onPause() {
        stopScan()
        super.onPause()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}

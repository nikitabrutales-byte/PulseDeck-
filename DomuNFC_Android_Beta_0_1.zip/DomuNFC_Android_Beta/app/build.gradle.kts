plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "cz.domunfc.beta"
    compileSdk = 35
    defaultConfig {
        applicationId = "cz.domunfc.beta"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "0.1"
    }
}

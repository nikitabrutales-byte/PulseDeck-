# Domu NFC — Android Beta 0.1

Česká nativní Android aplikace pro základní NFC diagnostiku.

## Funkce
- Zjistí, zda zařízení má NFC a zda je NFC zapnuté.
- Pomocí Android Reader Mode detekuje podporované NFC technologie.
- Zkusí ověřit, zda je tag běžný NDEF tag.
- Nezobrazuje ani neukládá UID/identifikátor čipu.
- Nepokouší se kopírovat, emulovat ani obcházet přístupové oprávnění.

## Sestavení APK
1. Nainstaluj Android Studio a aktuální JDK 17.
2. Otevři v Android Studiu složku `DomuNFC_Android_Beta`.
3. Nech Gradle dokončit synchronizaci.
4. Zvol Build → Build Bundle(s) / APK(s) → Build APK(s).
5. Debug APK najdeš obvykle v `app/build/outputs/apk/debug/app-debug.apk`.

Projekt potřebuje Android SDK platform 35 a Gradle plugin se stáhne při synchronizaci, takže je potřeba internet.

## Důležité limity
NFC telefon neumí obecně číst 125kHz RFID ani univerzálně emulovat zabezpečené domovní přístupové karty. Výsledek je orientační. Pro skutečný mobilní klíč je nutná podpora a oprávněné vydání klíče správcem/výrobcem přístupového systému.
